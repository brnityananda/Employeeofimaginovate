package com.imaginovate.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee {

	
	@Id
	private Long empId;
	@Column(name="Employee_name")
	private String name;
	@Column(name="Employee_salary")
	private Double salary;
	
	public Long getEmpId() {
	    return empId;
	}

	public void setEmpId(Long empId) {
	    this.empId = empId;
	}

	public String getName() {
	    return name;
	}

	public void setName(String name) {
	    this.name = name;
	}

	public Double getSalary() {
	    return salary;
	}

	public void setSalary(Double salary) {
	    this.salary = salary;
	}

}


