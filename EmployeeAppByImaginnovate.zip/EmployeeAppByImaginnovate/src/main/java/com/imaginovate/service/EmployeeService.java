package com.imaginovate.service;

import com.imaginovate.entity.Employee;

public interface EmployeeService {
	
	public Employee saveemployee(Employee employee);
	
	public Employee getEmployee(Long empId);

}
